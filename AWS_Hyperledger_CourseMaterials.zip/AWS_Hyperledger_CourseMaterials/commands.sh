## Connect to EC2 instance in Fabric network

Chmod 400 my_aws_key.pem

ssh -i yourkey.pem -r ec2-user@<Instance IP address>ls -l ~/

ls -l ~/HyperLedger-BasicNetwork/artifacts/docker-compose/

cd ~/HyperLedger-BasicNetwork/artifacts/docker-compose/

docker-compose -f docker-compose-cli.yaml ps

ls -l /etc/fabric/

## Fix the bug in the docker-compose-cli.yaml file

cd HyperLedger-BasicNetwork/artifacts/docker-compose/
nano docker-compose-cli.yaml
# Remove the blank after /opt in /opt /gopath in line 68 

## Redeploy the CLI container

IMAGE_TAG=latest docker-compose -f docker-compose-cli.yaml up -d --no-deps cli

## Connect to CLI container
docker-compose -f docker-compose-cli.yaml exec cli bash

ls
export | grep PEER | grep -v TLS

exit

## Begin coding up the chaincode file
## The actual contents of the chaincode is in another attachment
nano art_registry.go

## Copy chaincode to CLI container
docker cp art_registry.go cli:/opt/gopath/src/github.com/chaincode/
docker exec -it cli bash

## Setting the terminal prompt
export PS1="\[\e[34m\]\w\[\e[m\]>\n-->"

cd /opt/gopath/src/github.com/chaincode/
ls
cd /opt/gopath/src/github.com/hyperledger/fabric/peer

## Install chaincode on a peer
peer chaincode install -n mydapp -v 1.0 -p github.com/chaincode/

peer chaincode list --installed

## Set the location of the certificat authority file for the Orderer
export ORDERER_CA=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem

## Instantiate the chaincode
peer chaincode instantiate -o orderer.example.com:7050 --tls --cafile $ORDERER_CA -C mychannel -n mydapp -v 1.0 -c '{"Args":["Mona Lisa","The Louvre museum"]}' 

## Invoking a transaction
peer chaincode invoke -o orderer.example.com:7050 --tls --cafile $ORDERER_CA -C mychannel -n mydapp -c '{"Args":["setOwner", "Diana and Callisto","The Duke of Sutherland"]}'

## Query the chaincode
peer chaincode query -C mychannel -n mydapp -c '{"Args":["getOwner","Mona Lisa"]}'

peer chaincode query -C mychannel -n mydapp -c '{"Args":["getOwner","Diana and Callisto"]}'

peer chaincode invoke -o orderer.example.com:7050 --tls --cafile $ORDERER_CA -C mychannel -n mydapp -c '{"Args":["setOwner", "Diana and Callisto","The National Gallery London"]}'


peer chaincode query -C mychannel -n mydapp -c '{"Args":["getOwner","Diana and Callisto"]}'

# Exit from the container
exit

exit
